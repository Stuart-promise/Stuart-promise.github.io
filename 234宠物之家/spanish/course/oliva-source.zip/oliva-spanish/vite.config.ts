import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { VitePWA } from 'vite-plugin-pwa'
import { defineConfig } from 'vitest/config'

// The Workbox matcher callbacks below execute inside the generated service worker.
declare const self: { location: URL }

export default defineConfig({
  base: './',
  build: { license: { fileName: 'THIRD_PARTY.txt' } },
  plugins: [
    react(),
    tailwindcss(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['favicon.svg', 'apple-touch-icon.png'],
      manifest: {
        name: 'Oliva 橄榄西语',
        short_name: 'Oliva',
        description: '从零到 C1 的西班牙语互动学习',
        lang: 'zh-CN',
        theme_color: '#58a14a',
        background_color: '#f7f8f3',
        display: 'standalone',
        start_url: './',
        scope: './',
        icons: [
          { src: 'pwa-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'pwa-512.png', sizes: '512x512', type: 'image/png' },
          { src: 'pwa-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        ],
      },
      workbox: {
        cacheId: 'pet234-spanish-course',
        additionalManifestEntries: [
          { url: '../../account.js?v=spanish1&course-offline=1', revision: 'spanish1' },
          { url: '../storage.js?v=1&course-offline=1', revision: 'spanish1' },
        ],
        // The shared site's identity and sync scripts should see independent website
        // updates immediately. Install an offline fallback for the first offline visit.
        runtimeCaching: [
          {
            urlPattern: ({ url, request }) => request.destination === 'script' && url.origin === self.location.origin
              && url.pathname === new URL('../../account.js', self.location.href).pathname,
            handler: 'NetworkFirst',
            options: { cacheName: 'pet234-spanish-course-shared-v1', networkTimeoutSeconds: 4,
              precacheFallback: { fallbackURL: '../../account.js?v=spanish1&course-offline=1' } },
          },
          {
            urlPattern: ({ url, request }) => request.destination === 'script' && url.origin === self.location.origin
              && url.pathname === new URL('../storage.js', self.location.href).pathname,
            handler: 'NetworkFirst',
            options: { cacheName: 'pet234-spanish-course-shared-v1', networkTimeoutSeconds: 4,
              precacheFallback: { fallbackURL: '../storage.js?v=1&course-offline=1' } },
          },
        ],
        globPatterns: ['**/*.{js,css,html,svg,png,woff2}'],
        maximumFileSizeToCacheInBytes: 6 * 1024 * 1024,
        navigateFallback: 'index.html',
      },
    }),
  ],
  test: {
    environment: 'node',
    include: ['src/**/*.test.ts'],
  },
})
