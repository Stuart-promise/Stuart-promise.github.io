import Dexie, { type DBCore } from 'dexie'
import { db } from './db'

const tableNames = ['cards', 'reviews', 'mistakes', 'notebook', 'exams', 'chats', 'aiDict', 'aiReadings', 'papers', 'userSongs', 'songLyrics']
const journal = db.table<Checkpoint, string>('cloudJournal')
interface Checkpoint { name: string; base: string | null; pending: boolean }

async function encode(name: string, records: Record<string, unknown>[]) {
  const rows = name === 'songLyrics' ? records.filter(row => row.source === 'manual') : records
  if (!rows.length) return null
  const text = JSON.stringify(rows)
  if (text.length < 8192 || typeof CompressionStream === 'undefined') return text
  const compressed = new Blob([text]).stream().pipeThrough(new CompressionStream('gzip'))
  const bytes = new Uint8Array(await new Response(compressed).arrayBuffer())
  const chunks = []
  for (let i = 0; i < bytes.length; i += 8192) chunks.push(String.fromCharCode(...bytes.subarray(i, i + 8192)))
  return 'gz:' + btoa(chunks.join(''))
}

async function decode(name: string, value: string | null) {
  if (!value) return []
  if (value.startsWith('gz:')) {
    const raw = atob(value.slice(3)), bytes = Uint8Array.from(raw, ch => ch.charCodeAt(0))
    value = await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).text()
  }
  const rows: Record<string, unknown>[] = JSON.parse(value)
  if (!Array.isArray(rows)) throw Error('账号中的课程数据格式无效')
  if (name === 'cards') {
    for (const row of rows) {
      row.due = new Date(row.due as string)
      if (row.last_review) row.last_review = new Date(row.last_review as string)
    }
  }
  return rows
}

async function applyValue(name: string, value: string | null) {
  const table = db.table(name)
  const rows = await Dexie.waitFor(decode(name, value))
  if (name === 'songLyrics') await table.filter(row => row.source === 'manual').delete()
  else await table.clear()
  if (rows.length) await table.bulkPut(rows)
  await journal.put({ name, base: value, pending: false })
}

// Mark a table dirty inside the same IndexedDB transaction as its mutation.
// A tab closed before the account cache is updated can replay it on next open.
function trackTransactions(core: DBCore): DBCore {
  const tracked = new WeakSet<object>()
  return {
    ...core,
    transaction(stores, mode, options) {
      const dirty = mode === 'readwrite' && !stores.includes('cloudJournal') && stores.some(name => tableNames.includes(name))
      const tx = core.transaction(dirty ? [...stores, 'cloudJournal'] : stores, mode, options)
      if (dirty) {
        tracked.add(tx)
        ;(tx as IDBTransaction).addEventListener('complete', scheduleFlush)
      }
      return tx
    },
    table(name) {
      const table = core.table(name)
      if (!tableNames.includes(name)) return table
      return {
        ...table,
        async mutate(req) {
          if (tracked.has(req.trans)) {
            const marks = core.table('cloudJournal')
            const prior: Checkpoint | undefined = await marks.get({ trans: req.trans, key: name })
            if (!prior?.pending) {
              const result = await marks.mutate({ type: 'put', trans: req.trans, values: [{ name, base: prior?.base ?? null, pending: true }] })
              if (result.numFailures) throw Object.values(result.failures)[0]
            }
          }
          return table.mutate(req)
        },
      }
    },
  }
}

let flushing: Promise<void> | undefined
let requested = false
export function flushCourseTables(): Promise<void> {
  requested = true
  if (flushing) return flushing
  flushing = (async () => {
    while (requested) {
      requested = false
      const pending = (await journal.toArray()).filter(row => row.pending)
      for (const { name } of pending) {
        await db.transaction('rw', [db.table(name), journal], async () => {
          const row = await journal.get(name)
          if (!row?.pending) return
          const key = 'course.table.' + name
          const remote = window.PetSpanish.getItem(key)
          const data = await db.table(name).toArray()
          const local = await Dexie.waitFor(encode(name, data))
          if (row.base !== remote && local !== remote) {
            const keepLocal = window.confirm('这台设备有未同步的西语学习记录，账号中也有新的记录。点「确定」保留本机版本，点「取消」使用账号版本。')
            if (!keepLocal) { await applyValue(name, remote); return }
          }
          if (local !== remote) {
            if (local === null) window.PetSpanish.removeItem(key)
            else window.PetSpanish.setItem(key, local)
          }
          await journal.put({ name, base: local, pending: false })
        })
      }
    }
  })().finally(() => { flushing = undefined })
  return flushing
}

function scheduleFlush() {
  flushCourseTables().then(() => document.getElementById('course-sync-error')?.remove()).catch(error => {
    let note = document.getElementById('course-sync-error')
    if (!note) {
      note = document.createElement('a')
      note.id = 'course-sync-error'
      note.setAttribute('role', 'alert')
      ;(note as HTMLAnchorElement).href = '../../account.html'
      document.body.append(note)
    }
    note.textContent = '课程记录暂存本机 · ' + (error instanceof Error ? error.message : '请查看账号状态')
  })
}

export async function prepareCourseTables() {
  db.use({ stack: 'dbcore', name: 'pet234-course-journal', create: trackTransactions })
  await db.open()
  await flushCourseTables()
  for (const name of tableNames) {
    const value = window.PetSpanish.getItem('course.table.' + name)
    await db.transaction('rw', [db.table(name), journal], async () => {
      const row = await journal.get(name)
      if (!row?.pending && (!row || row.base !== value)) await applyValue(name, value)
    })
  }
  document.addEventListener('visibilitychange', () => { if (document.hidden) scheduleFlush() })
  window.addEventListener('online', scheduleFlush)
  window.addEventListener('spanish-progress-changed', e => {
    if ((e as CustomEvent<string[]>).detail?.some(key => key.startsWith('course.'))) {
      flushCourseTables().then(() => location.reload()).catch(scheduleFlush)
    }
  })
}
