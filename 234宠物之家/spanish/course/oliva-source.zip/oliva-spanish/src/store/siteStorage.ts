import { createJSONStorage } from 'zustand/middleware'

interface SiteStorage {
  ready: Promise<unknown>
  owner: string
  status: string
  getItem(key: string): string | null
  setItem(key: string, value: string): void
  removeItem(key: string): void
}

declare global {
  interface Window { PetSpanish: SiteStorage }
}

export function courseOwner(): string {
  return typeof window === 'undefined' ? 'test' : window.PetSpanish.owner
}

export function deviceKey(key: string) {
  return 'pet234:spanish-device:' + courseOwner() + ':' + key
}

export const profileStorage = {
  getItem(key: string) {
    const value = window.PetSpanish.getItem(key)
    if (key !== 'course.settings') return value
    const secret = localStorage.getItem(deviceKey('gemini'))
    if (!secret) return value
    const settings = value ? JSON.parse(value) : { state: {}, version: 2 }
    settings.state.gemini = JSON.parse(secret)
    return JSON.stringify(settings)
  },
  setItem(key: string, value: string) {
    if (key === 'course.settings') {
      const settings = JSON.parse(value)
      if (settings.state.gemini) {
        localStorage.setItem(deviceKey('gemini'), JSON.stringify(settings.state.gemini))
        delete settings.state.gemini
      }
      value = JSON.stringify(settings)
    }
    window.PetSpanish.setItem(key, value)
  },
  removeItem(key: string) {
    window.PetSpanish.removeItem(key)
  },
}

export const siteJSONStorage = <T,>() => typeof window === 'undefined' ? undefined : createJSONStorage<T>(() => profileStorage)
