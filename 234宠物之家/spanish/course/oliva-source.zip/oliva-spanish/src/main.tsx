import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import '@fontsource/nunito/latin-400.css'
import '@fontsource/nunito/latin-600.css'
import '@fontsource/nunito/latin-700.css'
import '@fontsource/nunito/latin-800.css'
import '@fontsource/nunito/latin-900.css'
import './index.css'
const root = createRoot(document.getElementById('root')!)
async function start() {
  if (!window.PetSpanish) throw Error('无法连接学习存档，请联网后重试。')
  await window.PetSpanish.ready
  const { prepareCourseTables } = await import('./store/cloudTables')
  await prepareCourseTables()
  const { default: App } = await import('./App')
  root.render(<StrictMode><App /></StrictMode>)
}
start().catch(error => root.render(
  <main className="mx-auto max-w-lg p-6">
    <h1 className="mb-3 text-xl font-bold">课程暂未打开</h1>
    <p>{error instanceof Error ? error.message : '请重新载入学习记录。'}</p>
    <div className="mt-4 flex gap-4"><button onClick={() => location.reload()}>重新载入</button><a href="../">返回西语学习</a></div>
  </main>,
))
